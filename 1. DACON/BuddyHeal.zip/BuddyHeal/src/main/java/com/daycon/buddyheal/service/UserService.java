package com.daycon.buddyheal.service;

import com.daycon.buddyheal.model.UserInfoDTO;

public interface UserService {

	public UserInfoDTO registerOrLogin(String email, String name);
		
}
