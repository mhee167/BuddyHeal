package com.daycon.buddyheal.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.daycon.buddyheal.config.GPTConfig;
import com.daycon.buddyheal.dto.GPTRequestDTO;
import com.daycon.buddyheal.dto.GPTResponseDTO;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@PropertySource("classpath:/properties/gpt.properties")
public class GPTServiceImpl implements GPTService{

	private RestTemplate restTemplate;
	private final String apiUrl;
	private final String apiKey;
	private final String model;


	  public GPTServiceImpl(RestTemplate restTemplate, @Value("${gpt.api.url}") String apiUrl, @Value("${gpt.api.key}") String apiKey, @Value("${gpt.model}") String model) {
        this.restTemplate = restTemplate;
        this.apiUrl = apiUrl;
        this.apiKey = apiKey;
        this.model = model;
    }
	
	
	public String chat(String prompt) {
		
		GPTRequestDTO request = new GPTRequestDTO(
				  model,prompt,1,256,1,2,2);
				
		//지정된 url(apiURL)로 post 요청을 전송. 요청 본문은 request 객체 -> 이 객체는 GPTRequestDTO 클래스의 인스턴스임. 
		GPTResponseDTO gptResponse = restTemplate.postForObject(apiUrl, request, GPTResponseDTO.class);
		  
		if (gptResponse != null && !gptResponse.getChoices().isEmpty()) {
	            return gptResponse.getChoices().get(0).getMessage().getContent();
	        } else {
	            return "No response";
	        }
	}

}
