package com.daycon.buddyheal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.daycon.buddyheal.dao.UserRepository;
import com.daycon.buddyheal.model.UserInfoDTO;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository user;
	
	//회원가입 | 로그인 서비스
	@Override
	public UserInfoDTO registerOrLogin(String email, String name) {
		//회원가입된 회원인 지 판단.
		String user_name = user.getUserInfo(email);
	
		UserInfoDTO user_info = new UserInfoDTO();
		user_info.setUser_email(email);
		user_info.setUser_name(name);
		
		if(user_name==null) {
			user.registerUser(email,name);
		}
		
		return user_info;
	}

	
}
