package com.daycon.buddyheal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.daycon.buddyheal.dto.GPTRequestDTO;
import com.daycon.buddyheal.dto.GPTResponseDTO;
import com.daycon.buddyheal.service.GPTService;
import com.daycon.buddyheal.service.GPTServiceImpl;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/gpt")

public class GPTController {

	private final GPTServiceImpl service;
	
	@Autowired
	public GPTController(GPTServiceImpl gptService) {
		this.service = gptService;
	}

	
	@GetMapping("/chat")
	public String chat(@RequestParam("prompt") String prompt) {
		return service.chat(prompt);	
		
	}
	
}
