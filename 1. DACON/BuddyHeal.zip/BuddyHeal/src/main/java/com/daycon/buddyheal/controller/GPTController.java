package com.daycon.buddyheal.controller;


import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.daycon.buddyheal.model.ChatLogDTO;
import com.daycon.buddyheal.model.GPTRequestDTO;
import com.daycon.buddyheal.model.GPTResponseDTO;
import com.daycon.buddyheal.service.GPTService;
import com.daycon.buddyheal.service.GPTServiceImpl;

import lombok.RequiredArgsConstructor;



@Controller
@CrossOrigin(origins = "*")
@PropertySource("classpath:application.properties")
public class GPTController {
	
	private final RestTemplate restTemplate = new RestTemplate();
	 
    @Value("${node.server.url}")
    private String nodeServerUrl;
    
    
	@Autowired
	private GPTServiceImpl openAIService;

  
	//硫붿씤 �럹�씠吏� �꽕�젙.
    @GetMapping("/")
    public String getMainPage() {
    	return "index";
    }

    //�뿬湲곗꽌 諛붾줈 return chatbot jsp x
	@GetMapping("/googleLogin")
	public String getChatPage(HttpSession session,Model model) {
	    return "redirect:/chatbot";
	}
    
	// 以꾨컮轅� 諛� 遺덊븘�슂�븳 怨듬갚 �젣嫄�
	public String cleanResponse(String response) {
	      return response.replaceAll("\\r\\n|\\r|\\n", "<br>").trim();
	     
	 }
	
	@GetMapping("/chat")
	    public ResponseEntity<String> chat(@RequestParam("prompt") String prompt,@RequestParam("question_timestamp") String question_timestamp, HttpSession session,Model model) throws UnsupportedEncodingException {
		 
		 	String url = UriComponentsBuilder.fromHttpUrl(nodeServerUrl + "/gpts").toUriString();

	        HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(new MediaType("application", "json", StandardCharsets.UTF_8)); //request瑜� 蹂대궪 �븣 �븳湲� 源⑥쭚 �쁽�긽 諛⑹�.

	        String requestJson = "{ \"text\": \"" + prompt + "\" }";
	        	     
	        HttpEntity<String> request = new HttpEntity<>(requestJson, headers);
	        
	      
	        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, request, String.class);

	       
	        //json �삎�떇�씤 �쓳�떟 泥섎━
	        String responseBody = response.getBody();
	        JSONObject jsonObject = new JSONObject(responseBody);
	        String message = jsonObject.getString("response");	   	
	       	        
	      	        	        
			//�꽭�뀡�뿉 ���옣�맂 �씠硫붿씪 �젙蹂� �샇異�. 
			String email = (String) session.getAttribute("email");
			
		  	// GPT �꽌鍮꾩뒪 �샇異�
	        //String response = openAIService.chat(prompt);
	      	
	        //response_timestamp ���옣
	        LocalDateTime now = LocalDateTime.now();
	        
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy. MM. dd HH:mm");
	        
	        String response_timestamp = now.format(formatter);
	      
	        // �쓳�떟�쓽 以꾨컮轅� 諛� 遺덊븘�슂�븳 怨듬갚 �젣嫄�
	        String cleanedResponse = cleanResponse(message);
	        model.addAttribute("response", cleanedResponse);
	        
	        // ���솕 湲곕줉 ���옣
	        openAIService.saveChatLog(prompt, cleanedResponse , email,question_timestamp,response_timestamp );
	       
	    
	        return ResponseEntity.ok()
	                .header("Content-Type", "text/plain;charset=UTF-8")
	                .body(cleanedResponse);
	    }
	
	@GetMapping("/getSessionValidMem")
	public ResponseEntity<String> getSessionValidMem(HttpSession session) {
		String ValidMem = (String) session.getAttribute("ValidMem");
		
		return ResponseEntity.ok(ValidMem); //ajax�뒗 json�삎�떇�쓣 �썝�븿. 
	}
	  
}

