package com.daycon.buddyheal.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.daycon.buddyheal.dto.GPTRequestDTO;
import com.daycon.buddyheal.dto.GPTResponseDTO;

@Service
@PropertySource("classpath:/properties/gpt.properties")// properties를 읽음
public class GPTServiceImpl implements GPTService {


		//http 요청을 보내기 위해 사용됨
		private RestTemplate restTemplate;
		// @value 어노테이션을 통해 properties파일에서 값을 주입받음(밑에 3개)
		// api의 url
		private final String apiUrl;
		//api key
		private final String apiKey;
		//사용할 모델의 이름
		private final String model;

		// 서비스 생성자-> @value DI를 통해 properties값을 초기화
		  public GPTServiceImpl(RestTemplate restTemplate, @Value("${gpt.api.url}") String apiUrl, @Value("${gpt.api.key}") String apiKey, @Value("${gpt.model}") String model) {
	        this.restTemplate = restTemplate;
	        this.apiUrl = apiUrl;
	        this.apiKey = apiKey;
	        this.model = model;
	    }
		
		//chat메서드 - > 서비스의 일종
			public String chat(String prompt) {
				// prompt=입력한 텍스트,temparature=모델응답의 다양성 조정(텍스트가 다양해짐), 응답할 최대 토큰 수(최대 4092)
				GPTRequestDTO request = new GPTRequestDTO(model,prompt,1,1024,1,2,2);
						
				//지정된 url(apiURL)로 post 요청을 전송. 요청 본문은 request 객체 -> 이 객체는 GPTRequestDTO 클래스의 인스턴스임. 
				GPTResponseDTO gptResponse = restTemplate.postForObject(apiUrl, request, GPTResponseDTO.class);
				//응답 처리- choices가 비어있지 않으면 첫번째 응답의 메세지 내용을 반환
				//응답이 쌓이면 choices의 응답을 저장할 수 있는가????
				if (gptResponse != null && !gptResponse.getChoices().isEmpty()) {
			            return gptResponse.getChoices().get(0).getMessage().getContent();
			        } else {
			            return "No response";
			        }
			}

    
		    // 맨 처음에 나올 말들
		    public String handleOption(int option) {
		        switch (option) {
		            case 1:
		                return "서울시 7월의 감염병 발생률 예측에 대한 정보를 제공하겠습니다. 자세한 사항을 입력해 주세요.";
		            case 2:
		                return "강남구 근처의 소아과 병원 리스트를 아래에 제공해 드립니다:\n\n" +
		                       "강남소아과의원 - 서울특별시 강남구 역삼동\n" +
		                       "한빛소아청소년과의원 - 서울특별시 강남구 삼성동\n" +
		                       "아이사랑소아과의원 - 서울특별시 강남구 신사동\n" +
		                       "이 외에도 더 필요하시면 말씀해 주세요!";
		            case 3:
		                return "예방 접종에 대한 정보를 제공해 드리겠습니다. 궁금한 예방 접종 종류나 일정을 입력해 주세요.";
		            case 4:
		                return "다음 달에 아이들이 걸리기 쉬운 질병과 그 원인은 가을철 독감입니다. 독감은 인플루엔자 바이러스에 의해 발생하며, 예방 접종과 개인 위생 관리를 철저히 하는 것이 중요합니다.";
		            case 5:
		                return "질병 예측에 대한 자세한 정보를 제공하겠습니다. 궁금한 사항을 입력해 주세요.";
		            case 6:
		                return "기타 궁금한 사항을 입력해 주세요.";
		            default:
		                return "알 수 없는 선택입니다. 다시 시도해 주세요.";
		        }
		    }
}
