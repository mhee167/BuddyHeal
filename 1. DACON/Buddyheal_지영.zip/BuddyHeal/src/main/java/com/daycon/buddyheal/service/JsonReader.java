package com.daycon.buddyheal.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class JsonReader {
    private static final Logger logger = LoggerFactory.getLogger(JsonReader.class);
    private JsonNode jsonData;

    @PostConstruct
    public void init() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            // ClassLoader를 사용하여 리소스 파일을 읽음
            ClassLoader classLoader = getClass().getClassLoader();
            try (InputStream inputStream = classLoader.getResourceAsStream("data/prediction_data.json")) {
                if (inputStream == null) {
                    logger.error("JSON 파일이 존재하지 않습니다: data/prediction_data.json");
                    return;
                }

                jsonData = objectMapper.readTree(inputStream);
                logger.info("JSON 데이터가 성공적으로 로드되었습니다.");
            }
        } catch (IOException e) {
            logger.error("JSON 데이터를 로드하는 중 오류 발생", e);
        }
    }

    public String findResponse(String city, String date) {
        if (jsonData == null) {
            logger.error("JSON 데이터가 로드되지 않았습니다.");
            return "JSON 데이터가 로드되지 않았습니다.";
        }

        for (JsonNode element : jsonData) {
            if (element.has("date") && element.get("date").asText().equals(date) && element.has("y")) {
                double rate = element.get("y").asDouble();
                return String.format("%s년 %s월의 질병률은 %.2f%%입니다.조심하세요",date.substring(0, 4), date.substring(4, 6), rate);
            }
        }
        return "관련 데이터를 찾을 수 없습니다.";
    }
}