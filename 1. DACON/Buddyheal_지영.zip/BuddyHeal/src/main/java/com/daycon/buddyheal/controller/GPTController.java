package com.daycon.buddyheal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.daycon.buddyheal.dto.GPTRequestDTO;
import com.daycon.buddyheal.dto.GPTResponseDTO;
import com.daycon.buddyheal.service.GPTService;
import com.daycon.buddyheal.service.GPTServiceImpl;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/gpt")

public class GPTController {

	private final GPTServiceImpl service;

	
	@Autowired
	public GPTController(GPTServiceImpl gptService) {
		this.service = gptService;

	}

	
	@GetMapping("/chat")
    public ResponseEntity<String> chat(@RequestParam("prompt") String prompt) {
        String response;
        switch (prompt) {
            case "서울시 7월 감염발생률 예측":
                response = service.handleOption(1);
                break;
            case "소아과 위치 및 가까운 의료 시설 추천":
                response = service.handleOption(2);
                break;
            case "예방 접종 정보 알아보기":
                response = service.handleOption(3);
                break;
            case "요즘 쉽게 걸리는 질병의 예방 정보를 제공":
                response = service.handleOption(4);
                break;
            case "질병예측 자세히 보러가기":
                response = service.handleOption(5);
                break;
            default:
                response = service.handleOption(6);
                break;
        }

        return ResponseEntity.ok()
                .header("Content-Type", "text/plain;charset=UTF-8")
                .body(response);
    }
	

	
}
