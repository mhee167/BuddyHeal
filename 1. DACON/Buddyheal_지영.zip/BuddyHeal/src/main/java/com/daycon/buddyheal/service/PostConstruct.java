package com.daycon.buddyheal.service;

public @interface PostConstruct {

}
