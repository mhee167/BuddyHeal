package com.daycon.buddyheal.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
//json 이름 변환 전략 지정. jackson이 json을 역/직렬화할 때 필드 이름을 특정 형식으로 변환. 
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)// -> 어차피 지금 필요하진 않음. 차라리 필드 이름을 모두 카멜케이스로 고정하면 안되려나

// 요청객체 초기화
public class GPTRequestDTO {

	private String model;
    private List<Message> messages;
    private int temperature;
    private int maxTokens;
    private int topP;
    private int frequencyPenalty;
    private int presencePenalty;

    public GPTRequestDTO(String model
            , String prompt
            , int temperature
            , int maxTokens
            , int topP
            , int frequencyPenalty
            , int presencePenalty) {
    	
        this.model = model;
        this.messages = new ArrayList<>();
        // 프롬프트를 포함하는 메세지 객체를 추가함
        this.messages.add(new Message("user",prompt));
        
        // 출력 텍스트의 다양성을 조정하는 파라미터 값이 높을수록 생성된 텍스트가 다양해지고 낮을수록 텍스트가 더 예측 가능해진다. 0.0~1.0
        this.temperature = temperature;
        //
        this.maxTokens = maxTokens;
        //샘플링을 위한 누적 확률 임계값 - 0.9라면 합이 0.9에 도달할 때까지 후보단어들을 고려한다.높은 확률을 가진 단어들만 선택해서 의미있는 답을 완성한다.
        this.topP=topP;
        // 모델이 동일한 단어를 여러번 생성하는 것을 얼마나 억제할지- 값이 높을수록 동일한 반복을 억제한다.
        this.frequencyPenalty=frequencyPenalty;
        //특정 단어가 텍스트에 처음 나타날때 패널티-> 값이 높을 수록 새로운 단어는 배제한다.
        this.presencePenalty = presencePenalty;

    }
	
}
