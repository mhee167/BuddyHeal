package com.daycon.buddyheal.controller;

import java.net.http.HttpHeaders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.daycon.buddyheal.dto.GPTRequestDTO;
import com.daycon.buddyheal.dto.GPTResponseDTO;
import com.daycon.buddyheal.service.GPTService;
import com.daycon.buddyheal.service.GPTServiceImpl;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/gpt")
public class GPTController {

	private final GPTServiceImpl service;
	
	@Autowired
	public GPTController(GPTServiceImpl gptService) {
		this.service = gptService;
	}

	
	  @GetMapping("/chat")
	    public ResponseEntity<String> chat(@RequestParam("prompt") String prompt) {
	        // GPT 서비스 호출
	        String response = service.chat(prompt);
	        // 응답의 Content-Type을 text/plain;charset=UTF-8로 설정
	        return ResponseEntity.ok()
	                .header("Content-Type", "text/plain;charset=UTF-8")
	                .body(response);
	    }
	
}
