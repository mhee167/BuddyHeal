package com.daycon.buddyheal.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.daycon.buddyheal.dto.GPTRequestDTO;

@Service
public interface GPTService {	
	
	String chat(String prompt);	
}
