document.addEventListener('DOMContentLoaded', () => {
    const target = document.querySelector('.company');
    const targets = document.querySelectorAll('.scroll_event');

    // 페이지가 로드되면 active
    target.classList.add('active');

    // 스크롤 시 active
    window.addEventListener('scroll', () => {
        targets.forEach(target => {
            const rect = target.getBoundingClientRect();
            const windowHeight = window.innerHeight || document.documentElement.clientHeight;

            if (rect.top <= windowHeight - 130 && rect.bottom >= 130) {
                target.classList.add('active');
            }
        });
    });
});
