package com.daycon.buddyheal.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ChatLogVO {
	
	private int conversation_id;
	private int user_id;
	private List<String> question;
	private List<String> response;
	
}
