package com.daycon.buddyheal.service;

import com.daycon.buddyheal.model.UserInfoVO;

public interface UserService {

	public UserInfoVO registerOrLogin(String email, String name);
		
}
