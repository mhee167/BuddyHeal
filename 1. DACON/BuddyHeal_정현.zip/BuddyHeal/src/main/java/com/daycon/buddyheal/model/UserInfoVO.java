package com.daycon.buddyheal.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UserInfoVO {

	private String user_email;
	private String user_name;
}
