$(document).ready(function () {
    /* 로그인 영역 */
    const loginPopup = $('#login_popup');
    const closePopup = $('#close_popup');
    const chatbotPage = $('#chat_container');

    // 로그인 성공 시 팝업 클로즈, 챗봇 페이지를 활성화
    $('.login_google').on('click', function () {
        alert('구글 로그인이 완료되었습니다.');
        loginPopup.hide();
        chatbotPage.removeClass('blurred');
    });

    /* 챗봇 */
    // 첫 번째 메시지 자동 표시
    var initialMessage = '<div class="gpt_message_container">' +
        '<img src="/buddyheal/resources/img/ico/chatbot.png" alt="Didimi" class="chatbot_image">' +
        '<div class="message gpt_message">' +
        '<img src="/buddyheal/resources/img/img/chatbot_message.png" alt="Didimi" class="message_img">' +
        '<p>안녕하세요! 건강지킴이 챗봇 "디딤이"입니다.<br>저는 여러분이 궁금한 모든것들을 답변해 드릴 수 있어요!<br><br>어떻게 질문할지 고민되신다면 아래의 메뉴를 활용해 보세요 :)</p>' +
        '<ul class="btn_message">' +
        '<li><button class="menu_button">아동 감염 질병률 예측</button></li>' +
        '<li><button class="menu_button">가까운 소아과 찾기</button></li>' +
        '<li><button class="menu_button">예방접종 일정 안내</button></li>' +
        '<li><button class="menu_button">데이터 분석 그래프 보기</button></li>' +
        '</ul>' +
        '</div>' +
        '</div>';
    $("#chat_box").append(initialMessage);

    scrollToBottom(); // 페이지 로드 시 맨 아래로 스크롤

    $("#chat_form").on("submit", function (event) {
        event.preventDefault();
        sendPrompt();
    });

    $("#prompt").on("focus", function () {
        $(this).attr("placeholder", "");
    }).on("blur", function () {
        $(this).attr("placeholder", "디딤이에게 물어보세요");
    });

    // 엔터 키 이벤트
    $("#prompt").on("keydown", function (event) {
        if (event.key === "Enter" && !event.shiftKey) {
            event.preventDefault();
            sendPrompt();
        }
    });

    // 입력 시 텍스트 영역 높이 조정
    $("#prompt").on("input", function () {
        adjustTextareaHeight();
    });

    // 메뉴 버튼 클릭 이벤트
    $(".menu_button").on("click", function () {
        var message = $(this).text();
        $("#chat_box").append('<div class="user_message_container"><div class="message user_message"><p>' + message + '</p><span class="timestamp">' + new Date().toLocaleTimeString() + '</span></div></div>');
        sendPromptFromMenu(message); // 메뉴 버튼 클릭 시 sendPromptFromMenu 호출
    });
});

function adjustTextareaHeight() {
    var textarea = document.getElementById("prompt");
    textarea.style.height = "40px"; // 초기 높이
    textarea.style.height = (textarea.scrollHeight) + "px";
}

function sendPrompt() {
    var prompt = $("#prompt").val().replace(/\n/g, '<br/>'); // 줄 바꿈을 유지
    var timestamp = new Date().toLocaleTimeString();

    if (prompt.trim() === '') {
        alert("메시지를 입력해주세요.");
        return;
    }

    // 사용자의 메시지를 채팅 박스에 표시
    $("#chat_box").append('<div class="user_message_container"><div class="message user_message"><p>' + prompt + '</p><span class="timestamp">' + timestamp + '</span></div></div>');
    scrollToBottom(); // 사용자의 메시지 추가 후 스크롤 맨 아래로 이동

    $.ajax({
        url: "/gpt/chat",
        type: "GET",
        data: { prompt: prompt },
        success: function (response) {
            var timestamp = new Date().toLocaleTimeString();
            $("#chat_box").append(
                '<div class="gpt_message_container">' +
                '<img src="/buddyheal/resources/img/ico/chatbot.png" alt="Didimi" class="chatbot_image">' +
                '<div class="message gpt_message"><p>' + response + '</p><span class="timestamp">' + timestamp + '</span></div>' +
                '</div>'
            );
            scrollToBottom(); // GPT 메시지 추가 후 스크롤 맨 아래로 이동
        },
        error: function (xhr, status, error) {
            var timestamp = new Date().toLocaleTimeString();
            $("#chat_box").append(
                '<div class="gpt_message_container">' +
                '<img src="/buddyheal/resources/img/ico/chatbot.png" alt="Didimi" class="chatbot_image">' +
                '<div class="message gpt_message"><p>Error: ' + error + '</p><span class="timestamp">' + timestamp + '</span></div>' +
                '</div>'
            );
            scrollToBottom(); // 오류 메시지 추가 후 스크롤 맨 아래로 이동
            console.log(xhr.responseText); // 오류 응답 본문을 콘솔에 출력
        }
    });

    $("#prompt").val(''); // 입력 필드를 지움
    adjustTextareaHeight(); // 텍스트 영역 높이를 초기화
}

function sendPromptFromMenu(message) {
    $.ajax({
        url: "/gpt/chat",
        type: "GET",
        data: { prompt: message },
        success: function (response) {
            var timestamp = new Date().toLocaleTimeString();
            $("#chat_box").append(
                '<div class="gpt_message_container">' +
                '<img src="/buddyheal/resources/img/ico/chatbot.png" alt="Didimi" class="chatbot_image">' +
                '<div class="message gpt_message"><p>' + response + '</p><span class="timestamp">' + timestamp + '</span></div>' +
                '</div>'
            );
            scrollToBottom(); // GPT 메시지 추가 후 스크롤 맨 아래로 이동
        },
        error: function (xhr, status, error) {
            var timestamp = new Date().toLocaleTimeString();
            $("#chat_box").append(
                '<div class="gpt_message_container">' +
                '<img src="/buddyheal/resources/img/ico/chatbot.png" alt="Didimi" class="chatbot_image">' +
                '<div class="message gpt_message"><p>Error: ' + error + '</p><span class="timestamp">' + timestamp + '</span></div>' +
                '</div>'
            );
            scrollToBottom(); // 오류 메시지 추가 후 스크롤 맨 아래로 이동
            console.log(xhr.responseText); // 오류 응답 본문을 콘솔에 출력
        }
    });
}

function scrollToBottom() {
    $("#chat_box").scrollTop($("#chat_box")[0].scrollHeight);
}