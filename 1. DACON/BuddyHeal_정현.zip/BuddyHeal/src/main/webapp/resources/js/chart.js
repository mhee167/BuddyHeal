// 수두 발병률 예측
let ctx_pred = document.getElementById('chart_prediction').getContext('2d');
let chart01 = new Chart(ctx_pred, {
    type: 'line', 
    data: {
        labels: ['2024-06-01', '2024-07-01', '2024-08-01', '2024-10-01', '2024-11-01', '2024-12-01'],
        datasets: [{
            label: '수두 발병률',
            data: [142, 141.482, 139.626, 97.268, 145.916, 142.559, 120.705],
            // fill: false,
            // borderColor: 'rgb(75, 192, 192)',
            // tension: 0.1,
            borderColor: '#9D88F6',
            backgroundColor: 'rgba(157, 136, 246, 0.15)',
            borderWidth: 2,
            maintainAspectRatio: false
        }]
    },
    options: {
        responsive: false,
        legend: false,
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        },
    }
});

// 수두 발병률 참고 데이터 01
let ctx_case01 = document.getElementById('chart_cause01').getContext('2d');
let chart02 = new Chart(ctx_case01, {
    type: 'line', 
    data: {
        labels: ['01월', '02월', '03월', '04월', '05월', '06월', '07월', '08월', '09월', '10월', '11월', '12월'],
        datasets: [{
            label: '2022년 수두 발병률',
            data: [92, 99, 113, 118, 134, 147, 132, 137, 84, 112, 106, 102],
            borderColor: '#999',
            borderWidth: 2,
            fill: false,
        }, {
            label: '2023년 수두 발병률',
            data: [83, 89, 105, 133, 149, 103, 129, 121, 90, 160, 160, 121],
            borderColor: '#3982F0',
            borderWidth: 2,
            fill: false,
        }]
    },
    options: {
        responsive: false,
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        },
    }
});

// 수두 발병률 참고 데이터 02
let ctx_case02 = document.getElementById('chart_cause02').getContext('2d');
let chart03 = new Chart(ctx_case02, {
    type: 'line', 
    data: {
        labels: ['01월', '02월', '03월', '04월', '05월', '06월', '07월', '08월', '09월', '10월', '11월', '12월'],
        datasets: [{
            label: '2022년 일산화탄소',
            data: [0.64, 0.53, 0.45, 0.41, 0.36, 0.33, 0.36, 0.34, 0.36, 0.42, 0.57, 0.53],
            borderColor: '#999',
            borderWidth: 2,
            fill: false,
        }, {
            label: '2023년 일산화탄소',
            data: [0.6, 0.55, 0.53, 0.41, 0.38, 0.39, 0.36, 0.35, 0.38, 0.45, 0.47, 0.57],
            borderColor: '#3982F0',
            borderWidth: 2,
            fill: false,
        }]
    },
    options: {
        responsive: false,
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        },
    }
});

// 수두 발병률 참고 데이터 03
let ctx_case03 = document.getElementById('chart_cause03').getContext('2d');
let chart04 = new Chart(ctx_case03, {
    type: 'line',
    data: {
    labels: ['01월', '02월', '03월', '04월', '05월', '06월', '07월', '08월', '09월', '10월', '11월', '12월'],              
    datasets: [{
            label: '2022년 최고기온',
            data: [2.6, 3.8, 12.7, 20.6, 25, 27.5, 31, 28.9, 27.2, 19.7, 15.4, 1.7],
            borderColor: '#aaa',
            borderWidth: 2,
            fill: false,
        }, {
            label: '2023년 최고기온',
            data: [3.2, 7.3, 16.2, 19, 25, 27.9, 30.2, 30.8, 27.6, 21, 11.5, 5.2],
            borderColor: '#3982F0',
            borderWidth: 2,
            fill: false,
        }]
    },
    options: {
        responsive: false,
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        },
    }
});

// 수두 발병률 참고 데이터 04
let ctx_case04 = document.getElementById('chart_cause04').getContext('2d');
let chart05 = new Chart(ctx_case04, {
    type: 'line', 
    data: {
        labels: ['01월', '02월', '03월', '04월', '05월', '06월', '07월', '08월', '09월', '10월', '11월', '12월'],
        datasets: [{
            label: '2022년 이산화질소',
            data: [0.032, 0.0258, 0.0257, 0.0196, 0.0152, 0.0132, 0.0136, 0.0136, 0.0132, 0.0155, 0.0204, 0.0285, 0.0277],
            borderColor: '#999',
            borderWidth: 2,
            fill: false,
        }, {
            label: '2023년 이산화질소',
            data: [0.0297, 0.0291, 0.0271, 0.0183, 0.0169, 0.0141, 0.0135, 0.0122, 0.0136, 0.0212, 0.0216, 0.0283],
            borderColor: '#3982F0',
            borderWidth: 2,
            fill: false,
        }]
    },
    options: {
        responsive: false,
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        },
    }
});

// 예방 접종률
let ctx_vaccine = document.getElementById('chart_vaccine').getContext('2d');
var chart06 = new Chart(ctx_vaccine, {
    type: 'doughnut',
    data: {
        labels: ["중랑구", "금천구", "중구", "성북구", "송파구", "종로구", "양천구", "강남구"],
        datasets: [{
            label: '종합 예방 접종률',
            data: [9.107, 8.941, 8.521, 7.579, 7.414, 6.803, 6.6, 5.697],
            backgroundColor: [
                '#cbbeff',
                '#a8f7ff',
                '#d1ffa8',
                '#fff4a8',
                '#efefef',
                '#a8ffdf',
                '#a8bfff',
                '#ffa8a8',
              ],
        }]
    },
    options: {
        plugins: {
          legend: false,
          datalabels: {
            display: true,
            backgroundColor: '#ccc',
            borderRadius: 3,
            font: {
              color: 'red',
              weight: 'bold',
            },
          },
          doughnutlabel: {
            labels: [
              {
                text: '550',
                font: {
                  size: 20,
                  weight: 'bold',
                },
              },
            ],
          },
        },
      },
});