const OpenAI = require('openai')
const dotenv = require('dotenv')
const express = require('express')
const bodyParser = require('body-parser')
const cors = require('cors') // CORS 패키지 추가

dotenv.config()

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

const app = express()
app.use(bodyParser.json())
app.use(cors()) // CORS 설정 추가

async function getAssistant() {
  try {
    // Assistant를 비동기적으로 가져오기
    const assistant = await openai.beta.assistants.retrieve(
      process.env.GPTSKEY1
    )

    console.log('=----------------------------------')
    console.log('Assistant', assistant)
    console.log('Assistant ID:', assistant.id) // 이제 assistant.id가 올바르게 출력되어야 합니다.
  } catch (error) {
    console.error('Error retrieving assistant:', error)
  }
}

const assistant = getAssistant()

async function checkRunStatus(client, threadId, runId) {
  let run = await client.beta.threads.runs.retrieve(threadId, runId)

  var startTime = new Date()

  while (run.status !== 'completed') {
    await new Promise(resolve => setTimeout(resolve, 1000))
    run = await client.beta.threads.runs.retrieve(threadId, runId)
  }
}

app.post('/gpts', async (req, res) => {
  try {
    const recognizedText = req.body.text
    console.log(recognizedText)
    const thread = await openai.beta.threads.create()
    await openai.beta.threads.messages.create(thread.id, {
      role: 'user',
      content: recognizedText,
    })

    // assistant_id 변수를 미리 선언
    let assistant_id

    // Assistant를 비동기적으로 가져오기
    await openai.beta.assistants
      .retrieve(process.env.GPTSKEY1)
      .then(assistant => {
        assistant_id = assistant.id // 변수에 ID 할당
      })
      .catch(error => {
        console.error('Error retrieving assistant:', error)
        return res.status(500).json({ error: 'Failed to retrieve assistant' })
      })

    // assistant_id를 사용하여 Run 생성
    const run = await openai.beta.threads.runs.create(thread.id, {
      assistant_id: assistant_id,
      instructions: '',
    })

    await checkRunStatus(openai, thread.id, run.id)

    const message = await openai.beta.threads.messages.list(thread.id)
    const contents = message.body.data[0].content[0].text.value
    console.log(contents)
    res.json({ response: contents })
  } catch (error) {
    console.error('Error in /gpts route:', error) // 추가된 로그
    res.status(500).json({ error: error.message })
  }
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`)
})
