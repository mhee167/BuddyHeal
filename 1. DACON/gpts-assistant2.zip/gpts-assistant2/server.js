const OpenAI = require('openai');
const dotenv = require('dotenv');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors'); // CORS 패키지 추가

dotenv.config();


const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

const app = express();
app.use(bodyParser.json());
app.use(cors()); // CORS 설정 추가

async function getAssistant() {
  try {
    // Assistant를 비동기적으로 가져오기
    const assistant = await openai.beta.assistants.retrieve(process.env.GPTSKEY1);
    
    console.log("=----------------------------------");
    console.log('Assistant', assistant);
    console.log('Assistant ID:', assistant.id); // 이제 assistant.id가 올바르게 출력되어야 합니다.
  
  } catch (error) {
    console.error('Error retrieving assistant:', error);
  }
}


const assistant=getAssistant();


async function checkRunStatus(client, threadId, runId) {
  let run = await client.beta.threads.runs.retrieve(threadId, runId);

  const startTime = Date.now();
  let hasSentNotification = false;

  while (run.status !== "completed") {
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log(run.status);

    // 1분이 지나면 안내 문자 보내기 (한 번만)
    const currentTime = Date.now();
    if (!hasSentNotification && ((currentTime - startTime) > 60000 || run.status == 'failed')) {
      hasSentNotification = true;
      return { response: "데이터가 너무 많아서 지연되고 있습니다. 다시 시도해주시길 바랍니다.", status: "failed" };
    }

    run = await client.beta.threads.runs.retrieve(threadId, runId);
  }

  return { status: "completed" };
}

app.post('/gpts', async (req, res) => {
  const recognizedText = req.body.text.trim().toLowerCase();
  console.log(recognizedText);

  if (recognizedText === "가까운 소아과 찾기") {
    return res.json({ response: "원하시는 구를 입력해주시면, 제가 소아과를 찾아드릴게요! 😊 여러분의 소중한 아이를 위해 최적의 병원을 찾아드리겠습니다. 어떤 구를 입력해주실 건가요?" });
  } else {
    try {
      const thread = await openai.beta.threads.create();
      await openai.beta.threads.messages.create(thread.id, {
        role: "user",
        content: recognizedText
      });

      // Assistant를 비동기적으로 가져오기
      const assistant = await openai.beta.assistants.retrieve(process.env.GPTSKEY1);
      const assistant_id = assistant.id; // 변수에 ID 할당

      // assistant_id를 사용하여 Run 생성
      const run = await openai.beta.threads.runs.create(thread.id, {
        assistant_id: assistant_id,
        instructions: "",
      });

      const runStatus = await checkRunStatus(openai, thread.id, run.id);

      if (runStatus.status === "failed") {
        return res.json(runStatus);
      }

      const message = await openai.beta.threads.messages.list(thread.id);
      const contents = message.body.data[0].content[0].text.value;

      return res.json({ response: contents });
    } catch (error) {
      console.error('Error processing request:', error);
      return res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});