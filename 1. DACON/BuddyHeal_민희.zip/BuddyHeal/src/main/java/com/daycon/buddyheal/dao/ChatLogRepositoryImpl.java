package com.daycon.buddyheal.dao;


import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;
import org.springframework.jdbc.core.RowMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.daycon.buddyheal.model.ChatLogDTO;

@Repository
public class ChatLogRepositoryImpl implements ChatLogRepository {
	  
	@Autowired
	JdbcTemplate jdbcTemplate ;

	
	private class logMapper implements RowMapper<ChatLogDTO>{
		public ChatLogDTO mapRow(ResultSet rs, int count) throws SQLException{
			ChatLogDTO chat = new ChatLogDTO();
			chat.setConversation_id(rs.getInt("conversation_id"));
			chat.setQuestion(rs.getString("question"));
			chat.setResponse(rs.getString("response"));
			chat.setUser_id(rs.getString("user_id"));
			chat.setQuestion_timestamp(rs.getString("question_timestamp"));
			chat.setResponse_timestamp(rs.getString("response_timestamp"));
			return chat;
		}
	}
	
	
	//저장된 대화기록 조회 기능
	public List<ChatLogDTO> getChatLog(String email) {
		String sql = "SELECT * FROM CHAT_LOGS WHERE user_id=?";
		 return jdbcTemplate.query(sql, new Object[]{email}, new logMapper());
	}
	
	
	//지금까지의 대화기록 저장
	public void saveChatLog(String question,String response,String email, String question_timestamp, String response_timestamp) {
		String sql = "INSERT INTO chat_logs (question,response,user_id,question_timestamp, response_timestamp) VALUES(?,?,?,?,?)";
		jdbcTemplate.update(sql,question,response, email,question_timestamp, response_timestamp);
	}
	
}
