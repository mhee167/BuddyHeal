package com.daycon.buddyheal.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.RowMapper;
import com.daycon.buddyheal.model.UserInfoDTO;

@Repository
public class UserRepositoryImpl implements UserRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private class userMapper implements RowMapper<UserInfoDTO>{
		public UserInfoDTO mapRow(ResultSet rs, int count) throws SQLException{
			UserInfoDTO user = new UserInfoDTO();
			user.setUser_email(rs.getString("user_email"));
			user.setUser_name(rs.getString("user_name"));	
			return user;
		}
	}

	//사용자 회원가입 여부 판단하는 함수.
    @Override
    public String getUserInfo(String email) {
        String sql = "SELECT user_name FROM user_info WHERE user_email =?";
        try {
            return jdbcTemplate.queryForObject(sql, String.class,email);
        } catch (EmptyResultDataAccessException e) {
            // 이메일이 존재하지 않는 경우 처리
            System.out.println("No user found with email: " + email);
            return null;
        } catch (Exception e) {
            // 기타 예외 처리
            e.printStackTrace();
            return null;
        }
    }
	  
    //회원가입 기능.
	public void registerUser(String email, String name) {
		String sql = "INSERT INTO user_info(user_email,user_name) VALUES(?,?)";
		jdbcTemplate.update(sql,email,name);
	}

}
