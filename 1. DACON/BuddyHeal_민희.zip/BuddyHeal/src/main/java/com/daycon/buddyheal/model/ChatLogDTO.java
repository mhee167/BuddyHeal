package com.daycon.buddyheal.model;

import java.sql.Array;
import java.util.List;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ChatLogDTO {
	
	private int conversation_id;
	private String user_id;
	private String question;
	private String response;
	private String question_timestamp;
	private String response_timestamp;
	
}
