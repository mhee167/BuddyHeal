package com.daycon.buddyheal.controller;

import java.net.http.HttpHeaders;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.daycon.buddyheal.model.ChatLogDTO;
import com.daycon.buddyheal.model.GPTRequestDTO;
import com.daycon.buddyheal.model.GPTResponseDTO;
import com.daycon.buddyheal.service.GPTService;
import com.daycon.buddyheal.service.GPTServiceImpl;

import lombok.RequiredArgsConstructor;


@CrossOrigin(origins="http://localhost:8181")
@Controller
public class GPTController {
	
	@Autowired
	private GPTServiceImpl openAIService;

  
	//메인 페이지 설정.
    @GetMapping("/")
    public String getMainPage() {
    	return "index";
    }

    //여기서 바로 return chatbot jsp x
	@GetMapping("/googleLogin")
	public String getChatPage(HttpSession session,Model model) {
	    return "redirect:/chatbot";
	}
    
	// 줄바꿈 및 불필요한 공백 제거
	public String cleanResponse(String response) {
	      return response.replaceAll("\\r\\n|\\r|\\n", " ").trim();
	     
	 }
	
	@GetMapping("/chat")
	    public ResponseEntity<String> chat(@RequestParam("prompt") String prompt,@RequestParam("question_timestamp") String question_timestamp, HttpSession session,Model model) {
		  
			//세션에 저장된 이메일 정보 호출. 
			String email = (String) session.getAttribute("email");
			
		  	// GPT 서비스 호출
	        String response = openAIService.chat(prompt);
	      	
	        //response_timestamp 저장
	        LocalDateTime now = LocalDateTime.now();
	        
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy. MM. dd HH:mm");
	        
	        String response_timestamp = now.format(formatter);
	      
	        // 응답의 줄바꿈 및 불필요한 공백 제거
	        String cleanedResponse = cleanResponse(response);
	        
	        // 대화 기록 저장
	        openAIService.saveChatLog(prompt, cleanedResponse , email,question_timestamp,response_timestamp );
	       
	    
	        return ResponseEntity.ok()
	                .header("Content-Type", "text/plain;charset=UTF-8")
	                .body(cleanedResponse);
	    }
	
	@GetMapping("/getSessionValidMem")
	public ResponseEntity<String> getSessionValidMem(HttpSession session) {
		String ValidMem = (String) session.getAttribute("ValidMem");
		
		return ResponseEntity.ok(ValidMem); //ajax는 json형식을 원함. 
	}
	  
}

