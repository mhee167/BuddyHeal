package com.daycon.buddyheal.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.daycon.buddyheal.model.UserInfoDTO;

@Repository
public interface UserRepository {
	public String getUserInfo(String email);
	public void registerUser(String name, String email);
}
