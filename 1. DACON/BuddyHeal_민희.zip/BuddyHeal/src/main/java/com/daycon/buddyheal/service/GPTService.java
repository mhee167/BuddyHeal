package com.daycon.buddyheal.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.daycon.buddyheal.model.ChatLogDTO;
import com.daycon.buddyheal.model.GPTRequestDTO;

@Service
public interface GPTService {	
	
	public String chat(String prompt);
	public void saveChatLog(String prompt, String response,String email,String question_timestamp, String response_timestamp);
	public List<ChatLogDTO> getChatLog(String email);
	
}
