package com.daycon.buddyheal.dto;

import java.sql.ResultSet;

import javax.swing.tree.RowMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.daycon.buddyheal.model.ChatLogVO;

public class ChatLogRepositoryImpl implements ChatLogRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;
	/*
	private class ChatMapper implements RowMapper<ChatLogVO>{
		@Override
		public ChatLogVO mapRow(ResultSet rs, int count) throws SQLException{
			ChatLogVO chat = new ChatLogVO();
			chat.setConversation_id(rs.getInt("conversation_id"));
			chat.setQuestion(rs.getArray("question"));
			chat.setUser_id(rs.getInt("user_id"));
			chat.setResponse(rs.getString("response"));
		}
	}*/
	
	
}
