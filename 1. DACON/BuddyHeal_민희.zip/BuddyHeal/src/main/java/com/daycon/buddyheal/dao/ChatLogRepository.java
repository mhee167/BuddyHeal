package com.daycon.buddyheal.dao;

import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.swing.tree.RowMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.daycon.buddyheal.model.ChatLogDTO;


public interface ChatLogRepository {

	public List<ChatLogDTO> getChatLog(String email);
	public void saveChatLog(String question,String response,String email, String question_timestamp, String response_timestamp); 
}