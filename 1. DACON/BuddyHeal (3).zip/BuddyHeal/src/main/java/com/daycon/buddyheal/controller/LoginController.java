package com.daycon.buddyheal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.daycon.buddyheal.model.ChatLogDTO;
import com.daycon.buddyheal.service.GPTServiceImpl;
import com.daycon.buddyheal.service.UserServiceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;


@Controller
@PropertySource("classpath:/properties/login.properties")
@CrossOrigin(origins = "*")
public class LoginController {
	
	@Autowired
	UserServiceImpl user;

    @Value("${google.client.id}")
    private String clientId;

    @Value("${google.client.secret}")
    private String clientSecret;

    @Value("${google.redirect.uri}")
    private String redirectUri;

    @Value("${google.authorization.url}")
    private String authorizationUrl;

    @Value("${google.token.url}")
    private String tokenUrl;

    @Value("${google.user.info.url}")
    private String userInfoUrl;


 
    //oauth2 인증을 위한 url(인증 서버로의 요청) 생성.
    @GetMapping("/login")
    public String login() {
        String url = authorizationUrl + "?client_id=" + clientId + "&redirect_uri=" + redirectUri
                + "&response_type=code&scope=openid%20email%20profile";
        return "redirect:" + url;
    }
    
    //oauth2 인증을 처리하는 메서드.
    @GetMapping("/login/oauth2/code/google")
    public String oauth2Callback(@RequestParam("code") String code, Model model, HttpSession session) {
    	
        RestTemplate restTemplate = new RestTemplate();

        // 1. Access Token 요청/발급
        //액세스 토큰을 요청하기 위한 파라미터 
        Map<String, String> tokenRequest = new HashMap<>();
        tokenRequest.put("client_id", clientId);
        tokenRequest.put("client_secret", clientSecret);
        tokenRequest.put("code", code);
        tokenRequest.put("redirect_uri", redirectUri);
        tokenRequest.put("grant_type", "authorization_code");

        ResponseEntity<Map> tokenResponse = restTemplate.postForEntity(tokenUrl, tokenRequest, Map.class);
        String accessToken = (String) tokenResponse.getBody().get("access_token");

        // 2. User Info 요청
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer " + accessToken);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<Map> userInfoResponse = restTemplate.exchange(userInfoUrl, HttpMethod.GET, entity, Map.class);//exchange함수는 http메서드, 헤더 요청 본문등을 직접 설정 가능. 
        Map<String, Object> userInfo = userInfoResponse.getBody();

        // 3. 사용자 정보 추출
        String name = (String) userInfo.get("name");
        String email = (String) userInfo.get("email");
       
        //회원가입 / 로그인 기능 수행.
        user.registerOrLogin(email, name);
        
        // 4. 사용자 정보 모델에 추가
        session.setAttribute("email",email);
        session.setAttribute("ValidMem", "yes");
        model.addAttribute("userInfo", userInfo);

        
        return "redirect:/googleLogin";
    }
    
    
}
