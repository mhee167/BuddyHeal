package com.daycon.buddyheal.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.daycon.buddyheal.model.ChatLogDTO;
import com.daycon.buddyheal.service.GPTServiceImpl;

@Controller
@CrossOrigin(origins = "*")
public class WebController {
	
	@Autowired
	private GPTServiceImpl openAIService;

  
	// 챗봇 페이지로 이동
	@GetMapping("/chatbot")
	public String moveChatbot(Model model,HttpSession session) {
		 String email = (String) session.getAttribute("email");
		
		 List<ChatLogDTO> chatLogs = openAIService.getChatLog(email);
		 session.setAttribute("chatLogs",chatLogs);
		   
	    return "/chatbot/didimi";
	}
	
	// 질병률 페이지로 이동
	@GetMapping("/morbidity")
	public String moveMorbidity(Model model) {
	    return "/morbidity/analysis";
	}
	
}