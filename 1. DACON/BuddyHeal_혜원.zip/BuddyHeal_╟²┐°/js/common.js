document.addEventListener('DOMContentLoaded', () => {
    const floatingButton = document.querySelector('#up');

    // 스크롤 최상단으로 이동
    floatingButton.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});